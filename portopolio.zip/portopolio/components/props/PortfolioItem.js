import { View, Text } from 'react-native';

export default PortfolioItem = (props) => {
  return (
    <View
      style={{
        borderColor: '#FFFFFF55',
        borderWidth: 1,
        paddingHorizontal: 12,
        paddingTop: 16,
        paddingBottom: 24,
        gap: 8,
        marginVertical: 4
      }}>
      <Text
        style={{
          fontFamily: 'Lato-Light',
          color: '#FFFFFF',
          fontSize: 20,
        }}>
        {props.title}
      </Text>
      <Text
        style={{
          fontFamily: 'Lato-Thin',
          color: '#FFFFFF',
        }}>
        {props.description}
      </Text>
    </View>
  );
}
