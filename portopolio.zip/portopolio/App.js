import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  ScrollView,
} from 'react-native';
import PortfolioItem from './components/props/PortfolioItem';
import SectionTitle from './components/props/SectionTitle';
import Divider from './components/props/Divider';
import { useFonts } from 'expo-font';

function App() {
  const [fontLoaded] = useFonts({
    'Lato-Light': require('./assets/font/Lato-Light.ttf'),
    'Lato-Thin': require('./assets/font/Lato-Thin.ttf'),
    'Lato-Regular': require('./assets/font/Lato-Regular.ttf'),
  });

  if (!fontLoaded) return null;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.outerView}>
        <SectionTitle content="About Me" />
        <View style={styles.imageContainer}>
          <Image
            style={styles.image}
            source={require('./assets/20231014_101607.jpg')}
            resizeMode="stretch"
          />
        </View>
        <Text style={styles.aboutMeText}>
          Nama saya Gandhi Dhuta Nirvana. Saya adalah seseorang yang tertarik di
          bidang komputer.
        </Text>
        <Divider />
        <SectionTitle content="My Project" />
        <PortfolioItem
          title="DutaGames"
          description="Sebuah blanalblabalbalbalbalbalbalbalblbalbalbalablablablabalbblbalblanlnalnalablablablabal"
        />
        <PortfolioItem
          title="DutaGames"
          description="Sebuah blanalblabalbalbalbalbalbalbalblbalbalbalablablablabalbblbalblanlnalnalablablablabal"
        />
        <PortfolioItem
          title="DutaGames"
          description="Sebuah blanalblabalbalbalbalbalbalbalblbalbalbalablablablabalbblbalblanlnalnalablablablabal"
        />
      </ScrollView>
    </SafeAreaView>
  );
}

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    backgroundColor: '#000000',
    padding: 8,
  },
  outerView: {
    margin: 16,
    gap: 8,
    padding: 2,
  },
  imageContainer: {
    flexDirection: 'row',
    // height: 200,
  },
  image: {
    height: 150,
    width: 200,
  },
  aboutMeText: {
    color: 'white',
    fontFamily: 'Lato-Light',
    marginRight: 24,
    marginVertical: 12,
    fontSize:28
  },
});
